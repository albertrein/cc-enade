<?php
/*
* Captura dados
* Chamada Cadastro de perguntas
* valida
* salva
* retorna dados
array(8) { 
$_POST["corpo_questao"]=> string(8) "12312312" 
$_POST["imagem"]=> string(28) "photo4969881094459599249.jpg" 
$_POST["alternativa_a"]=> string(3) "312" 
$_POST["alternativa_b"]=> string(3) "123" 
$_POST["alternativa_c"]=> string(3) "123" 
$_POST["alternativa_d"]=> string(3) "123"
$_POST["alternativa_e"]=> string(3) "123" 
$_POST["resposta"]=> string(1) "E" }
*/

if(empty($_POST['corpo_questao'])){
	die('<h1>Verifica o Corpo da questao</h1>');
}

if(!isset($_FILES['imagem']['name'])){
	$_POST['imagem'] = "";
}

if(empty($_POST['alternativa_a'])){
	die('<h1>Verifica a questao a</h1>');
}

if(empty($_POST['alternativa_b'])){
	die('<h1>Verifica a questao b</h1>');
}

if(empty($_POST['alternativa_c'])){
	die('<h1>Verifica a questao c</h1>');
}

if(empty($_POST['alternativa_d'])){
	die('<h1>Verifica a questao d</h1>');
}

if(empty($_POST['alternativa_e'])){
	die('<h1>Verifica a questao e</h1>');
}

if(empty($_POST['resposta'])){
	die('<h1>Verifica a Resposta</h1>');
}

require '../Model/CadastroPerguntas.php';
$cadastroPerguntalModel = new CadastroPerguntas();

if($retorno = $cadastroPerguntalModel->salvarPergunta($_POST)){
	$retorno =  mysqli_fetch_assoc($retorno)["id"];

	if(!isset($_FILES['imagem']['name'])){
		die('h1>Salvo sem imagem.</h1>');
	}

	move_uploaded_file($_FILES['imagem']['tmp_name'], '../imagens_questoes/'.$retorno.'.jpg');

	die('<h1>Salvo!</h1>');
}
die('<h1>Erro.</h1>');