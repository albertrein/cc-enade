CREATE TABLE questoes(
	questaopk INT AUTO_INCREMENT PRIMARY KEY,
	corpo VARCHAR(255) NOT NULL,
	imagem VARCHAR(128),
	alternativa_a VARCHAR (255) NOT NULL,
	alternativa_b VARCHAR(255) NOT NULL,
	alternativa_c VARCHAR(255) NOT NULL,
	alternativa_d VARCHAR(255) NOT NULL,
	alternativa_e VARCHAR(255) NOT NULL,
	resposta VARCHAR(20) NOT NULL
);

ALTER TABLE questoes ADD CONSTRAINT chk_resposta CHECK (resposta IN ('A' , 'B' , 'C' , 'D' , 'E'));