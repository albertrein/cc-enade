<?php

use Model\DatabaseConnection\MySqlConnection;

require('DatabaseConnection/MysqlConnection.php');

class CadastroPerguntas extends MySqlConnection{
	private $conn;

	function __construct(){
		parent::__construct();
		$this->conn = parent::getConnection();
		return false;
	}

	function salvarPergunta($dados){
		$sql = "INSERT INTO questoes(corpo, imagem, alternativa_a, alternativa_b, alternativa_c, alternativa_d, alternativa_e, resposta) VALUES ('";
		$sql .= $dados['corpo_questao']."', '";
		$sql .= $dados['imagem']."', '";
		$sql .= $dados['alternativa_a']."', '";
		$sql .= $dados['alternativa_b']."', '";
		$sql .= $dados['alternativa_c']."', '";
		$sql .= $dados['alternativa_d']."', '";
		$sql .= $dados['alternativa_e']."', '";
		$sql .= $dados['resposta']. "');";
		
		
		echo $sql;
		if($this->conn->query($sql)){
			return $this->retornaUltimoIdRegistrado();
		}
		return false;
	}

	function retornaUltimoIdRegistrado(){
		return $this->conn->query('SELECT MAX(questaopk) as id FROM questoes;');
	}

}
