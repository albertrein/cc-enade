<?php

namespace Model\DatabaseConnection;

class MySqlConnection{
	private $host;
	private $user;
	private $pass;
	private $database;
	private $conn;
	function __construct(){
		$this->host = 'db';
		$this->user = 'root';
		$this->pass = 'phprs';
		$this->database = 'phprs';
		try{
			$this->conn =  mysqli_connect($this->host, $this->user, $this->pass, $this->database);
		}catch(Exception $e){
			die('Erro Conexao'.$e);
		}		
	}

	public function getConnection(){
		return $this->conn;
	}

	public function TestConnection(){
		if ($this->conn->connect_error) {
		    throw new Exception("Connection failed: " . $this->conn->connect_error);
		} else {
		    echo "Connected to MySQL server successfully!";
		}
	}

}